//require('dotenv').config()

module.exports = {
    consumer_key: 'xxx',
    consumer_secret: 'xxx',
    access_token: 'xxx',
    access_token_secret: 'xxx'
}