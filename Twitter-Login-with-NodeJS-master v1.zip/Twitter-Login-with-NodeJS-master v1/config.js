//require('dotenv').config()

module.exports = {
    consumer_key: 'cKCfI1UdYlGhDxPm8gS37inn9',
    consumer_secret: 'SNBItq5yjHpKxC7oRFSlqVoZ24Vj46pDHcptecJogmoSjqb51P',
    access_token: '1497087080937451521-QFzvKHZt0riQ4PJsS5wWxeAlyBtNPL',
    access_token_secret: 'Z8Dt2Ul9uTPO2EAFnGJSX0YnOuxCjMTkK2mNt9v4NF4pJ'
}